package com.production.ZhasIntern.Controller;

import com.production.ZhasIntern.dto.InternshipDtos;
import com.production.ZhasIntern.service.InternshipService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/internships")
@RequiredArgsConstructor
public class InternshipController {

    private final InternshipService internshipService;

    // =========================================================
    // PUBLIC ENDPOINTS (No authentication required)
    // =========================================================

    /**
     * List published internships (public feed)
     */
    @GetMapping("/public")
    public Page<InternshipDtos.PublicItem> listPublic(
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return internshipService.listPublic(pageable);
    }

    /**
     * Get published internship details
     */
    @GetMapping("/public/{id}")
    public InternshipDtos.PublicDetails getPublic(@PathVariable UUID id) {
        return internshipService.getPublic(id);
    }

    // =========================================================
    // EMPLOYER ENDPOINTS (JWT required)
    // =========================================================

    /**
     * Create draft internship
     */
    @PostMapping("/drafts")
    public Map<String, UUID> createDraft(
            @AuthenticationPrincipal Jwt jwt,
            @RequestBody InternshipDtos.CreateRequest req
    ) {
        String employerId = jwt.getSubject(); // Supabase "sub"
        UUID id = internshipService.createDraft(employerId, req);
        return Map.of("id", id);
    }

    /**
     * List employer's internships (draft + published)
     */
    @GetMapping("/mine")
    public Page<InternshipDtos.MineItem> listMine(
            @AuthenticationPrincipal Jwt jwt,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        String employerId = jwt.getSubject();
        return internshipService.listMine(employerId, pageable);
    }

    /**
     * Publish internship
     */
    @PostMapping("/{id}/publish")
    public ResponseEntity<Void> publish(
            @AuthenticationPrincipal Jwt jwt,
            @PathVariable UUID id
    ) {
        String employerId = jwt.getSubject();
        internshipService.publish(employerId, id);
        return ResponseEntity.noContent().build();
    }
}
