package com.production.ZhasIntern.Controller;

import com.production.ZhasIntern.dto.EmployerApplicationDtos;
import com.production.ZhasIntern.service.EmployerApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/employer/internships/{internshipId}/applications")
public class EmployerApplicationController {

    private final EmployerApplicationService service;

    @PatchMapping("/{applicationId}/status")
    public ResponseEntity<Void> updateStatus(
            @PathVariable UUID internshipId,
            @PathVariable UUID applicationId,
            @RequestBody @Valid EmployerApplicationDtos.UpdateApplicationStatusRequest request,
            @AuthenticationPrincipal Jwt jwt
    ) {
        String employerUserId = jwt.getSubject();
        service.updateStatus(internshipId, applicationId, request.status(), employerUserId);
        return ResponseEntity.noContent().build(); // 204
    }
}