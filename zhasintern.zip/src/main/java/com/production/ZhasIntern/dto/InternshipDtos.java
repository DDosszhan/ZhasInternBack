package com.production.ZhasIntern.dto;

import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public class InternshipDtos {

    // what public list returns
    public record PublicItem(
            UUID id,
            String title,
            String companyName,
            String location,
            String type,
            Boolean isRemote,
            String shortDescription,
            Instant publishedAt,
            LocalDate deadline
    ) {}

    public record PublicDetails(
            UUID id,
            String title,
            String companyName,
            String location,
            String type,
            Boolean isRemote,
            String shortDescription,
            String description,
            Instant publishedAt,
            LocalDate deadline
    ) {}

    // create/update input
    public record CreateRequest(
            String title,
            String companyName,
            String location,
            String type, // ONSITE/REMOTE/HYBRID
            Boolean isRemote,
            String shortDescription,
            String description,
            LocalDate deadline
    ) {}

    // for employer "mine" list
    public record MineItem(
            UUID id,
            String title,
            String status,
            Instant createdAt,
            Instant updatedAt,
            Instant publishedAt,
            LocalDate deadline
    ) {}
}