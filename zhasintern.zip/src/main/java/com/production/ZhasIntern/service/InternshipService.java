package com.production.ZhasIntern.service;

import com.production.ZhasIntern.dto.InternshipDtos;
import com.production.ZhasIntern.entity.Internship;
import com.production.ZhasIntern.repository.InternshipRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class InternshipService {

    private final InternshipRepository repo;

    public InternshipService(InternshipRepository repo) {
        this.repo = repo;
    }

    public Page<InternshipDtos.PublicItem> listPublic(Pageable pageable) {
        return repo.findByStatusOrderByPublishedAtDesc(Internship.Status.PUBLISHED, pageable)
                .map(this::toPublicItem);
    }

    public InternshipDtos.PublicDetails getPublic(UUID id) {
        Internship it = repo.findByIdAndStatus(id, Internship.Status.PUBLISHED)
                .orElseThrow(() -> new NotFoundException("Internship not found"));
        return toPublicDetails(it);
    }

    public UUID createDraft(String employerId, InternshipDtos.CreateRequest req) {
        Internship it = new Internship();
        it.setEmployerId(employerId);
        it.setTitle(req.title());
        it.setCompanyName(req.companyName());
        it.setLocation(req.location());
        it.setType(parseType(req.type()));
        it.setIsRemote(req.isRemote() != null ? req.isRemote() : (parseType(req.type()) == Internship.WorkType.REMOTE));
        it.setShortDescription(req.shortDescription());
        it.setDescription(req.description());
        it.setDeadline(req.deadline());
        it.setStatus(Internship.Status.DRAFT);

        return repo.save(it).getId();
    }

    public Page<InternshipDtos.MineItem> listMine(String employerId, Pageable pageable) {
        return repo.findByEmployerIdOrderByCreatedAtDesc(employerId, pageable)
                .map(this::toMineItem);
    }

    public void publish(String employerId, UUID id) {
        Internship it = repo.findByIdAndEmployerId(id, employerId)
                .orElseThrow(() -> new NotFoundException("Internship not found"));

        if (it.getStatus() == Internship.Status.PUBLISHED) return;

        it.setStatus(Internship.Status.PUBLISHED);
        it.setPublishedAt(Instant.now());
        repo.save(it);
    }

    private Internship.WorkType parseType(String raw) {
        if (raw == null) return Internship.WorkType.ONSITE;
        try {
            return Internship.WorkType.valueOf(raw.toUpperCase());
        } catch (Exception e) {
            return Internship.WorkType.ONSITE;
        }
    }

    private InternshipDtos.PublicItem toPublicItem(Internship it) {
        return new InternshipDtos.PublicItem(
                it.getId(),
                it.getTitle(),
                it.getCompanyName(),
                it.getLocation(),
                it.getType() != null ? it.getType().name() : "UNKNOWN",
                it.getIsRemote(),
                it.getShortDescription(),
                it.getPublishedAt(),
                it.getDeadline()
        );
    }

    private InternshipDtos.PublicDetails toPublicDetails(Internship it) {
        return new InternshipDtos.PublicDetails(
                it.getId(),
                it.getTitle(),
                it.getCompanyName(),
                it.getLocation(),
                it.getType() != null ? it.getType().name() : "UNKNOWN",
                it.getIsRemote(),
                it.getShortDescription(),
                it.getDescription(),
                it.getPublishedAt(),
                it.getDeadline()
        );
    }

    private InternshipDtos.MineItem toMineItem(Internship it) {
        return new InternshipDtos.MineItem(
                it.getId(),
                it.getTitle(),
                it.getStatus().name(),
                it.getCreatedAt(),
                it.getUpdatedAt(),
                it.getPublishedAt(),
                it.getDeadline()
        );
    }

    // small custom exception
    public static class NotFoundException extends RuntimeException {
        public NotFoundException(String msg) { super(msg); }
    }
}
